import cross from "../assets/images/cross.png";

export const CrossICon = () => {
    return (
        <label htmlFor="openNav" className="cross-icon">
            <img src={cross} alt="X" />
        </label>
    )
}