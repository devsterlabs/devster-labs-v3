import eyesBlackImage from "../assets/images/eyes-black.png";

export const EyesBlack = () => {
    return (
        <img className="eyes-black" src={eyesBlackImage} alt="\ /" />
    )
}