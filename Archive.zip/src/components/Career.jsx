import { Link } from "react-router-dom";
import logoWhite from "../assets/images/logo-white.png";
import { LocaleContext } from "../context/LocaleContext";
import { Button } from "./Button";
import { useContext, useEffect, useState } from "react";
import { JD } from "./JD";
import { CustomButton } from "./CustomButton";

export const Career = () => {
  const jobs = [
    {
      title: "Data Scientist",
      experience: "5+ years",
      location: "Remote",
      id: "1",
    },
    {
      title: "React Native Developer",
      experience: "5+ years",
      location: "Islamabad, PK",
      id: "2",
    },
    {
      title: "Data Annotator",
      experience: "1 year",
      location: "Remote",
      id: "3",
    },
  ];
  return (
    <div id="teams" className="teams container" style={{ color: "#fff" }}>
      <div className="row" style={{ justifyContent: "center" }}>
        <span
          className="heading"
          style={{
            textAlign: "center",
          }}
        >
          <span className="heading" style={{ color: "#4cafc8" }}>
            JOB OPENINGS AT
          </span>{" "}
          <img
            src={logoWhite}
            style={{ marginBottom: "8px" }}
            className="logo-header"
            alt="Devster Labs"
          />
        </span>
      </div>
      <div className="career-container">
        {jobs.map((job, index) => (
          <div className="team-item" key={job.id}>
            <span className="name">{job.title}</span>
            <span className="txt18 semi op60">
              Experience: {job.experience}
            </span>
            <span className="txt18 semi op60">Location: {job.location}</span>
            <hr style={{ width: "100%" }} />
            <div className="btn-container">
              <span className="txt18 semi op60" style={{color: "#fff"}}>Posted: 05/01/2025</span>
              <Link to={"/career/" + job.id}>View Job Details</Link>
            </div>
          </div>
        ))}
      </div>
      <Button />
    </div>
  );
};
